package com.example.messagingapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.messagingapp.Models.MessageModel;
import com.example.messagingapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class ChatAdapter extends RecyclerView.Adapter{
    ArrayList<MessageModel> messageModels;
    Context context;

//    Because we have 2 viewHolders
    int SENDER_VIEW_TYPE=1;
    int RECEIVER_VIEW_TYPE=2;

    public ChatAdapter(ArrayList<MessageModel> messageModels, Context context) {
        this.messageModels = messageModels;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType == SENDER_VIEW_TYPE){
            View view = LayoutInflater.from(context).inflate(R.layout.sender_message,parent,false);
            return new SenderViewHolder(view);
        }
        else {
            View view = LayoutInflater.from(context).inflate(R.layout.receiver_message,parent,false);
            return new ReceiverViewHolder(view);
        }
    }
//For ViewHolders
    @Override
    public int getItemViewType(int position) {
//        Identifiying on which view type(sender,receiver or anything) which work should be done
//        sender is the one who has logged in the device so it will return sender id
        if(messageModels.get(position).getUid().equals(FirebaseAuth.getInstance().getUid())){
            return SENDER_VIEW_TYPE;
        }else{
            return RECEIVER_VIEW_TYPE;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
//        Data is set hare
//        Identifying sender and receiver messages
        MessageModel messageModel=messageModels.get(position);  //Whichever message comes first will be set first
        if(holder.getClass() == SenderViewHolder.class){
            ((SenderViewHolder)holder).senderMsg.setText(messageModel.getMessage());
            ((SenderViewHolder)holder).senderTime.setText(messageModel.getMessage());
        }else{
            ((ReceiverViewHolder)holder).receiverMsg.setText(messageModel.getMessage());
//            Time can also be set here
        }
    }
    @Override
    public int getItemCount() {
        return messageModels.size();
    }
//we have 2 layouts 1) sender 2) receiver
//Therefore there will be 2 viewholder

//    Receivers viewHolder
    public class ReceiverViewHolder extends RecyclerView.ViewHolder {
        TextView receiverMsg, receiverTime;
         public ReceiverViewHolder(@NonNull View itemView) {
              super(itemView);
              receiverMsg = itemView.findViewById(R.id.receiverId);
              receiverTime = itemView.findViewById(R.id.receiverTime);

        }
    }
//Sender ViewHolder
    public class SenderViewHolder extends  RecyclerView.ViewHolder {
         TextView senderMsg, senderTime;
         public SenderViewHolder(@NonNull View itemView) {
               super(itemView);
               senderMsg = itemView.findViewById(R.id.senderId);
               senderTime = itemView.findViewById(R.id.senderTime);
         }
    }
}
