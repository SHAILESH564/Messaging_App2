package com.example.messagingapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


import com.example.messagingapp.Models.MessageModel;
import com.example.messagingapp.adapter.ChatAdapter;
import com.example.messagingapp.databinding.ActivityChatDatailBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class ChatDatail extends AppCompatActivity {
   ActivityChatDatailBinding binding;
    FirebaseDatabase database;
    FirebaseAuth auth;
    final EncryDecry encryDecry = new EncryDecry();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatDatailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

       final String senderId = auth.getUid();// Get sender ID
//        From UserAdapter onBind
        String receiveId = getIntent().getStringExtra("userId");
        String userName = getIntent().getStringExtra("userName");
        String profilePic = getIntent().getStringExtra("ProfilePic");

        binding.userName2.setText(userName);
//        load Profile Picture
        Picasso.get().load(profilePic).placeholder(R.drawable.ic_profile).into(binding.profileimage);
        binding.backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChatDatail.this,MainActivity.class);
                startActivity(intent);
            }
        });

        final ArrayList<MessageModel> messageModels = new ArrayList<>();

        final ChatAdapter chatAdapter = new ChatAdapter(messageModels,this);
        binding.chatRecycler.setAdapter(chatAdapter);

        LinearLayoutManager layoutManager =new LinearLayoutManager(this);
        binding.chatRecycler.setLayoutManager(layoutManager);
//        ((LinearLayoutManager)binding.chatRecycler.getLayoutManager()).setStackFromEnd(true);

        final String senderRoom = senderId + receiveId;
        final String receiverRoom = receiveId + senderId;

//        Take data from firebase and add it show on recyclerview
            database.getReference().child("Chats").child(senderRoom).addValueEventListener(new ValueEventListener() {
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    messageModels.clear();

                    for(DataSnapshot snapshot1 : snapshot.getChildren()) {

                        MessageModel model = snapshot1.getValue(MessageModel.class);

                        messageModels.add(model);
                    }
                    chatAdapter.notifyDataSetChanged();//update recyclerview at runtime
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

//        send data to firebase and save
        binding.send.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                if(binding.sdMessage.getText().toString()==""){
                    binding.sdMessage.setError("Enter message");
                    
                }
               String message= binding.sdMessage.getText().toString();
                String message1 = null;
                try {
                    message1 = encryDecry.encryptString(message,"secretKey");
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                } catch (InvalidKeySpecException e) {
                    e.printStackTrace();
                } catch (InvalidKeyException e) {
                    e.printStackTrace();
                } catch (InvalidAlgorithmParameterException e) {
                    e.printStackTrace();
                } catch (NoSuchPaddingException e) {
                    e.printStackTrace();
                } catch (IllegalBlockSizeException e) {
                    e.printStackTrace();
                } catch (BadPaddingException e) {
                    e.printStackTrace();
                }


                final MessageModel model= new MessageModel(senderId,message);
                final MessageModel modele= new MessageModel(senderId,message1);
//               final MessageModel modeld= new MessageModel(senderId,message2);

               Long time = model.setTimestamp(new Date().getTime());

               binding.sdMessage.setText("");//Empty the text bar once message is send

                database.getReference().child("Chats").child(senderRoom).push().setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {

                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("Database sender", model.getMessage());

                    }
                });
                database.getReference().child("Chats").child(receiverRoom).push().setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                    }
                });
            }
        });



    }
}